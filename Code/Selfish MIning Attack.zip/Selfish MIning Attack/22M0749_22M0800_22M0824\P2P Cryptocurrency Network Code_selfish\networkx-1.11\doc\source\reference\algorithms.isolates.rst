********
Isolates
********

.. automodule:: networkx.algorithms.isolate
.. autosummary::
   :toctree: generated/

   is_isolate
   isolates
