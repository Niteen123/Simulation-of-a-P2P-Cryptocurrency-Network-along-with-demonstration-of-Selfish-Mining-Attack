transaction_list=[]  
transaction_id_list=[]
block_list=[]
block_id_list=[]
blockId=0
transaction_id=0
event_queue_list=[]
event_dict={}
time=0
slow_node=[]
low_cpu=[]
arun=0
very_wrong=0
n=0
slow_rate=0

