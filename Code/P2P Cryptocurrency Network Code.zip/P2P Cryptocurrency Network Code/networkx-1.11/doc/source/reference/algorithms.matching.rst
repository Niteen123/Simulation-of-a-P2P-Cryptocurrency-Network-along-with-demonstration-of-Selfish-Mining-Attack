********
Matching
********

.. automodule:: networkx.algorithms.matching
.. autosummary::
   :toctree: generated/

   maximal_matching
   max_weight_matching
