class transaction:
    def __init__(self,sender1,receiver1,coins,type,txn_id):
        self.sender1=sender1
        self.receiver1=receiver1
        self.coins=coins
        self.type=type
        self.txn_id=txn_id
        